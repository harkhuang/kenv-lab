export MALLOC_CONF="dirty_decay_ms:500"
